# Changelog

All notable changes to this project are documented here.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.1.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [0.3.2] - 2026-09-21

### New
- **Lumberjack.** A new villager who works a woodlot.  He plants saplings, knocks down trees, splits the fallen logs, and carries the wood home.
  Trees will be replanted with seeds in your chests, choosing the species that serves the wood you
  asked for: beech for wood, pine for core wood, birch or oak for fine wood.  Work orders are available for the various lumber types.
- **Villagers keep a feast on the table.** When a feast has been eaten down to nothing, a
  Farmer lays out a fresh one from your stores, in the same location.
- **The Food Preparation Table takes work orders.** Ask for a feast and your Farmer will
  make it, the same way orders work at a cauldron.

- **Villagers can walk through your gates.** A door was a wall as far as pathing was
  concerned: the navmesh is deliberately cut at every doorway so that leaving a gate open
  cannot make a village read as being outside its own walls — but the other half, a link
  bridging each doorway, had been switched off behind a TODO. The result was that a walled
  village trapped its own villagers: a Lumberjack could reach the inside of his gate and not
  one step past it, with his woodlot 60m beyond. Doorways are bridged again, and the ground
  immediately either side of a door is kept walkable so there is something to step onto.
- **Villagers can use a chest or station that is out of their plane.** A chest on a shelf
  above head height, or a station up on a foundation, used to be simply unreachable — the
  villager only ever looked for somewhere to stand at the thing's own height, so an order
  depending on it starved while the player opened it from below without noticing. A villager
  will now stand beside-and-below and reach up to 3m, but only where it can actually see what
  it is reaching for: no working through walls.

### Changed
- **Guards are learned from any biome map.** A village wants a guard from the day it has
  anything worth losing, and the guard was taught only by the Mistlands and Ashlands — so the
  settlements most in need of one, full of farmers with no defence, could not have any until
  the late game. Completing any biome's map now teaches the guard alongside whatever that
  biome specialises in.
- **A Forester's Post can stand much further out.** The limit was 50m, which is closer than
  you want to be felling trees near your walls; it is now 80m. The 50m was standing in for a
  real constraint — navmesh is only built around anchors, so a distant post used to bake a
  grove that was not joined to the village — so a post beyond one bake's reach now lays a line
  of anchors back home, keeping the walkable ground continuous the whole way. It refuses, and
  says so, if any point on that line has no walkable ground under it.

- **A woodlot claims far less ground.** The patch of outdoors a Forester's Post reserved for
  working was 28m in every direction, with an 8m-wide lane running back to the middle of the
  village — through the houses and across the wall. It is now 20m around the post and a 4m
  lane, and the lane starts at the gate the Lumberjack actually leaves by rather than at the
  village centre, since everything inside the walls is already village and needs no claiming.
- **Lumberjacks carry an armful, not a handful.** Breaking a log scatters wood across several
  metres as separate drops, and he was making a trip home for each one — the felling is quick,
  the carrying was the whole afternoon. He now sweeps up everything of the same kind within
  reach into one pile before setting off, and carries up to a full stack. Anything that will
  not fit stays where it is for the next trip.
- **Lumberjacks wait for the timber to come to rest.** A felled trunk rolls and slides for a
  few seconds, and he used to walk straight at it — or fell a second tree into the first one's
  path. The woodlot now pauses while anything is still falling, and when he goes back in he
  breaks up whichever log is nearest HIM first, since that is the one standing between him and
  everything else.

### Fixed
- **A dead villager handed out Mistlands loot.** Villagers are built on a Dvergr, and they had
  quietly kept the Dvergr's own drop table — so one dying in a Meadows starter village dropped
  black marble and coins, materials from a biome the player has no way to reach yet and a
  creature they never fought. That table is now stripped. A villager still returns the Lode
  Core that recruited it, exactly as before: that comes from the death itself, not the loot
  table, so the recruit → die → revive loop is unchanged.
- **Rooftops are no longer part of the map villagers navigate.** A roof read as a perfectly
  flat floor a storey above the village, and every test meant to catch that agreed with it —
  because a roof's *shape* is a pitched mesh but the thing it is built out of, for anything
  that asks about walking, is a plain box, and the top of a box is level however steep the
  tiles on it look. So villagers were offered a rooftop as somewhere to idle and somewhere to
  stand while reaching for a flower below, walked at it, and stopped. Roofs are now left out
  of the villager's map entirely, at the point where it is drawn. Gable end walls still count
  as walls.
- **The path out to a distant woodlot ran at a wall.** The lane kept walkable between a
  village and a far-flung Forester's Post was drawn from the middle of the settlement, so it
  left through the perimeter wherever that line happened to reach it — which on a walled
  village is a solid stretch of palisade, not a gate. The grove ended up walkable, on the map,
  and still an island the Lumberjack could not reach: `vv_forester_check` reported "region
  graph covers it: yes" and "villager can path to it: NO" at the same time. The lane now runs
  from the gate, and stepping stones that sit inside the walls are ignored rather than
  dragging it back indoors. `vv_forester_check` prints where the lane starts, and says so
  plainly when a village has no gates for it to start from. Two further reasons it kept
  happening: the list of gates is rebuilt from scratch every time the village map is and is
  not saved, so for the first rebuild after a server restart — the one that matters — there
  were no gates to start from yet and the lane quietly reverted to running from the middle
  of the village; and the rebuild a Forester's Post asks for when it is placed was being
  dropped the instant it was queued, so a lane that came out wrong stayed wrong.
- **A building's upper floor was built, shown, and then thrown away.** Anything a villager
  can walk onto is judged by how big a step up it is — but the step was measured against the
  *average* height of the whole surface being stepped onto, not the part actually underfoot.
  A staircase counts as one surface, so its average sits halfway up the flight: standing at
  the bottom, the first step read as over a metre and was refused. Everything the stairs led
  to was then unreachable and swept away with them, which is why a perfectly good upper storey
  would appear as the village map was drawn and then vanish. A step is now measured where you
  put your foot, so the size of a staircase no longer decides whether you can climb it.
- **Some rooms counted toward a village without being part of it.** Where a floor was laid
  flush on the ground, the floor and the ground underneath it competed for the same square,
  and the loser kept its name on the roll while losing every square it owned — present in the
  count, impossible to stand in. Those are now cleared out properly.
- **Villagers walked to the roof to pick a flower.** Choosing where to stand next to something
  that is not a station — a berry bush, a dandelion, a beehive — measured "near" across the
  ground only, ignoring height entirely. A plant under a first floor therefore resolved a
  standing spot on the floor ABOVE it: half a metre away as the crow flies, five and a half
  metres straight up, and up a staircase that did not exist. The villager then stood a few
  paces from the thing it wanted, holding a route it could never walk. Standing spots are now
  required to be on the same level as the thing they are for.
- **Lumberjacks never actually connected with a tree.** The run-up backs off a few metres and
  then sprints at the trunk — but the pathfinder was still holding the spot he backed off TO,
  so it spent the sprint pulling him back to where he started. He never closed the last couple
  of metres and every charge ended in a timeout. Whichever is steering now has it to itself.
- **A Lumberjack could stand idle in a woodlot full of trees.** The round offered exactly one
  tree and one log — the nearest of each — so a single target he could not work read as "no
  work here" and the whole woodlot went quiet. He now considers several, nearest first, and any
  reason one fails simply moves him to the next.
- **Guards patrol the walls again, not the woodlot.** Ground a village works but does not
  enclose — a woodlot, the lane out to it, the step outside a gate — was being treated as
  village interior, because "can a villager walk here" and "is this inside the walls" were the
  same flag. The boundary therefore ran around the outside of the woodlot, and the guard walked
  it: a patrol route reaching 85m from home, well beyond any wall. Those are now separate
  questions. Working ground outside the walls stays walkable, and stays outside: the boundary
  sits at the wall, the guard patrols it, and the Lumberjack still walks out to his trees.
- **A villager off the navmesh is no longer driven further off it.** Movement that steers the
  body rather than asking the pathfinder — crossing a doorway link, or an agent whose internal
  state has come adrift — is not bounded by walkable ground the way pathing is, so a villager
  that left the mesh kept being driven across open country. Three were found standing on bare
  terrain with no navmesh within 5m and the nearest walkable ground 78m away. A villager with
  no mesh under him now holds position instead.
- **A villager could be left walking by a task that had stopped running.** The one movement
  path that does not use pathfinding — the Lumberjack's run-up at a tree — hands the body a
  direction that it keeps using until something clears it. Anything that interrupted the run-up
  without ending it therefore left him walking in a straight line indefinitely, which is how
  one ended up 165m from home, twice, at the same spot. Movement of that kind now stops on its
  own the moment nothing is actively steering it.
- **The leash that stops villagers wandering off never actually worked.** A villager too far
  from home is supposed to be put back — it logged that it was doing so, every frame, while the
  villager carried on walking. The teleport shared a method with a debug-only rescue that is
  switched OFF by default, so the switch silently disabled the safety net too; villagers were
  found 165m and 198m from a village that claims to retrieve them at 60m. The leash is also no
  longer a fixed distance: it now measures from the furthest thing the village owns, because a
  Forester's Post can stand 80m out by design and a guard's own patrol route can run past 85m,
  and both were being "rescued" from work they were supposed to be doing.
- **A Lumberjack could charge a tree and keep going.** Felling starts with a run-up, which is
  deliberately a straight sprint with no pathfinding — and its only limit was a six-second
  timer, long enough at a run to carry him thirty metres past a trunk he could not reach and
  clean off the navmesh, where nothing could bring him back. The charge now also stops if he
  gets further from the tree than he started or leaves the navmesh, and a tree he has just
  failed to reach is left alone for a couple of minutes instead of being charged again
  immediately.
- **Villagers no longer write a log line every frame.** A villager's state line was written on
  every internal state assignment rather than on every state *change*, and behaviours re-assert
  their state each tick — so two alarmed villagers standing still produced thousands of
  identical lines a minute. On a dedicated server that is a hazard, not just noise.
- **Recall works from a client again**, and can now be run from the console with
  `vv_recall <name>` — useful on a dedicated server, where the registry UI is not available at
  all.
  Recall is the failsafe for a villager that has got
  itself into a bad state, so it has to work from wherever you are — but it decided everything
  on your own machine, where the two questions it asked cannot be answered. A villager too far
  away to be replicated to you is indistinguishable from one that is gone, and a client cannot
  move a villager the server owns, so recalling anything that had wandered out of range simply
  said "cannot recall". The host is now asked to do it: a villager that is loaded is moved, one
  that is unloaded has its stored position moved so it is waiting at the station when its zone
  next loads, and one the host genuinely cannot find is marked fallen so Revive can restore it.
  Recall also clears a paused villager and releases whatever work it had reserved.
- **A split stack of ingredients stalled an order forever.** The scan added an ingredient up
  across every chest in the village but remembered only the last chest it saw any in, then
  sent the villager to that one chest for the whole amount. Any ingredient spread over two
  chests therefore passed the check and failed the pickup: the villager abandoned, went idle,
  rescanned, matched the same order and did it again, several times a second. Ingredients are
  now collected chest by chest, and a villager that fails an order leaves it alone for a
  minute instead of rounding straight back on it.
- **A finished order no longer wears a warning triangle.** An order at its maximum was
  reported in the same list, and the same words, as one that is genuinely stuck — "blocked on
  1 orders: Sausages — Stocked 20 of 20". Satisfied orders are now kept separate, and a
  villager with nothing to do says whether that is because everything is stocked or because
  something needs your attention, rather than just "Idle".
- **Blocked work orders now say what to do about it.** Every reason a villager gives for not
  working an order names the specific thing that is wrong and the action that fixes it —
  which ingredient and where, which chest is full, which villager makes the recipe, whether
  the farm is out of seeds or out of space. Several of them were previously one label
  covering four different causes, so the stated reason was often not the real one.
- **"Missing ingredients" when the village was not missing them.** A chest inside the village
  that a villager has no walkable approach to is invisible to the fetch but still counted by
  the quota — so a village could report an order out of thistle and, in the same breath, that
  it already had 53 of them. Blocked orders now name the ingredient and say when it is present
  but out of reach, with the position of the chest to move, and a villager's own alert says
  "I can't reach the thistle" rather than claiming to be out of it.
- **A Forester's Post could report itself registered without saving anything.** The post
  writes its anchor to the village record, and the record refuses writes from a peer that does
  not own it — silently, while the post logged a cheerful "Registered anchor" either way. A
  post placed during that window kept a stale anchor through every restart, seeding the
  woodlot flood inside its own woodpile, and the grove stayed unreachable no matter how many
  times the village was repartitioned. The write is now checked, and the post retries until it
  takes.
- **Villagers could flood a server's log with approach diagnostics.** Two notices about
  awkward approach points were written every frame, per villager, per candidate — three
  cramped chests in one village produced thousands of identical lines a minute. On a dedicated
  server that is not just noise: the log is a pipe, and filling it stalls the main thread.
  Both are now reported once per target with a count of what was suppressed.
- **Villager stations were offering none of their own recipes.** Every villager's recipe
  list was silently dropped while loading its definition, so the Farmer's barley flour, the
  Tavern Keeper's cooked dishes and every other station recipe never registered — the
  stations looked empty for no visible reason. All of them now load. (Present since station
  recipes were introduced.)
- **The Lumberjack could never be unlocked.** Each biome map taught exactly one villager
  type, and the Black Forest's was already spoken for by the Carpenter — so combining Black
  Forest fragments quietly re-taught a type you already had and the Lumberjack never appeared
  in the registry, with nothing on screen to explain why. A biome map can now teach several
  types, and the Black Forest teaches both.
- **The Forester's Post had a stray box floating over it.** The banner's crossbar is a plain
  cube mesh, and the old code re-derived its rotation by hand and got it wrong, leaving a plank
  hanging in mid-air. The post is now a woodpile with a pole mast rising out of the middle and
  the banner flying at the top, every part keeping the rotation its donor gave it.
- **Carpenters endlessly "repaired" buildings that were never damaged.** Past world level 0
  the game scales a piece's maximum health up but leaves its stored health alone, so every
  intact wall in the village reported itself as half-destroyed to anything asking for a
  health percentage — while the repair itself, which measures health a different way,
  correctly did nothing. The carpenter was therefore sent to the same undamaged wall over
  and over, repaired nothing, and buried the log under thousands of identical lines while
  genuinely damaged pieces waited behind the phantoms. Damage is now measured the same way
  repairing measures it, and a piece that turns out not to need repair is set aside instead
  of being handed straight back.
- **A villager could freeze for good waiting on a station.** Once a craft reached the
  "waiting at the station" stage, the only way out was the station producing something — so
  if the food was taken off the cooking station by anyone else, or the output never arrived,
  the villager waited forever. Worse, it still counted as busy, so the scheduler handed it
  the same dead job every time instead of offering it anything new: it would stand wherever
  it happened to be, indefinitely, while work piled up feet away. A stalled craft is now
  given up on, and a cooking station with nothing on it is recognised straight away.
- **Villagers talked over their own work, and far too often.** A villager would deliver a
  line mid-stride while hauling or walking across the village, roughly every forty seconds,
  which ran through its handful of sayings in a couple of minutes. Now they speak only when
  they have nothing else on — and they stop walking to say it — at about one line every two
  minutes each, with a shared quiet period so a busy village doesn't turn into a chorus.
- **Villagers carried feasts and placed dishes off to a chest.** Food you set out on a table
  is a placed piece, but to a hauling villager it looked like something dropped on the floor.
  Anything the player has placed is now left where it is.
- **The Order button was missing at a station even when you had the villager for it.** It
  only appeared for villager types you had unlocked from a ransom-fragment map; a villager
  already living in your village — recruited, rescued or revived — now counts too.
- **The Farmer could refuse to plant near your buildings.** The spacing check measured
  distance in a way most building pieces don't support, so every spot near them read as
  occupied and was rejected, while the log filled with warnings.
- **A diagnostic console command could take a dedicated server down.** Its report was written
  as one oversized log line and its collision scan spammed errors; both are fixed, and the
  report is now a short summary instead of hundreds of lines.

## [0.3.1] - 2026-09-18

### Fixed
- **Villagers no longer turn back into ordinary Dvergr mages on a dedicated server.** A
  villager's identity lives in a separate record, and on a *client* that record arrives over
  the network independently of the villager itself. If the villager got there first, the game
  gave up on it permanently and left it standing in your village as a plain Dvergr — no name,
  no dialog, nothing to interact with — while the server quietly went on running the real
  villager. Reconnecting, or walking away and coming back, only re-rolled the same dice. A
  villager now waits for its record to arrive instead of giving up. Hosts and single-player
  were never affected. (Present since 0.2.6.)

## [0.3.0] - 2026-09-18

### New
- **Multiple villages work.** Each village keeps its own map, work orders, villagers and
  schedule, entirely independently — building in one leaves the others alone, and villagers
  in each get on with their own work. Previously a second village would corrupt the first's
  territory, and only one of them would ever rebuild its map.
  Two caveats: this has been tested with two villages on a listen host, not on a dedicated
  server, and villages closer together than about 200m are untested.

### Fixed
- **A second village no longer corrupts the first one's map.** Each village sized its
  territory from the combined boundary of *every* village, so with two settlements each
  one claimed hundreds of metres of the other's empty ground. That blew past the size cap,
  and the cap then trimmed the box around the village's own centre — cutting part of the
  village's own buildings out of its own territory. Territory is now measured per village.
- **With two or more villages, only one of them would rebuild its map.** A queued rebuild
  for one village counted as a duplicate of another village's and was silently dropped, so
  a second village's layout could stay stale indefinitely after you built there.
- **Recalling a villager no longer flings it out of the world.** Recall moved the villager to
  the station and then moved it *again* by the same amount, landing it roughly twice as far
  out — one recall to a station left a farmer 270m away in mid-air, where his zone unloaded
  and he appeared to vanish for good. The rescue that exists to drag a stray villager home
  had the identical fault, so it could not bring him back either. (Present since 0.2.6.)
- **Recall works on a villager that isn't loaded.** It previously did nothing but say "try
  again near the village" — useless advice, since a villager worth recalling is usually one
  that has ended up far enough away to unload. It now moves the villager regardless; it is
  standing at the station when you next get there.
- **Recall always moves the villager.** It used to give up silently if it couldn't find a
  tidy spot beside the station, which is exactly what happens when a villager is stuck or
  somewhere strange — the one time you actually need it.
- **Villagers no longer stall forever on work they cannot reach.** A chest, crop or plant
  spot inside the village but off the walkable map was still offered as work; the villager
  committed to it, failed to path there, and picked the identical target again next cycle —
  so orders it *could* have worked were never reached. Work is now only offered if the
  villager can actually walk to it, and a spot that fails is skipped for the rest of that
  session instead of being re-chosen.
- Farmers no longer end a whole planting session at the first plant spot they can't stand
  at, and no longer walk in a loop between the same unreachable spot and the farm.
- Villagers no longer log a spurious "lost context" warning and drop to idle each time the
  scheduler hands them a job, moments before that job's own scan result arrives.
- **The `vv_viz tri` wireframe now shows every village at once.** Only one village's grid
  was ever drawn — whichever rebuilt its map most recently — because all villages shared a
  single cache that each rebuild overwrote. The same cache fed `vv_probe`, which would
  report the nearest walkable surface as hundreds of metres away while you stood on a
  perfectly good one. Both now report per village, and `vv_probe` names which village a
  triangle belongs to.

### Removed
- **Saves from before 0.2 are no longer supported.** The one-time work-order migration
  (`vv_migrate_workorders`) has been removed, along with the fallback that read a quota
  off the legacy in-chest order token. A work order whose village record cannot be read
  now says so instead of silently displaying a 1-10 range.
- Vestigial dev commands: the offline HNA dump/record pipeline (nothing read its output),
  the scene-snapshot harness, the room catalog, and probes for bugs that have since been
  fixed.

### Changed
- **Building no longer rebuilds the map of villages nowhere near what you changed.** Every
  piece placed or removed, and every hoe stroke, used to rebuild every loaded village's
  map — including villages on the other side of the world. Each change now records where it
  happened, and only villages whose territory it touches rebuild.
- **Rebuilding a village's map now re-examines only the ground near what you changed.**
  Working out whether each patch of ground is walkable is the single most query-heavy part
  of the rebuild, and it was redone from scratch across the whole village every time. Those
  results are now remembered per patch and only re-taken where something actually changed —
  96% fewer physics and navmesh queries for a localised edit, for an identical map.
  `vv_repartition` on its own still re-examines everything, as the check on the fast path.
- Working out where a village's outer wall line falls is likewise remembered per patch of
  ground and only re-taken near a change, on both passes that need it — 98% fewer collision
  queries and over 99% fewer terrain height samples, again for an identical result.
- **Rebuilding a village's map no longer freezes the game while it happens.** The whole
  rebuild used to run inside a single frame — around a second of dead screen, twice over
  with two villages. It now runs in the background across roughly a hundred frames, one
  village at a time, and the navmesh rebuild itself runs off the main thread. Measured on a
  two-village world: the rebuild adds about 2.5ms to an average frame, with two brief
  spikes across the whole rebuild instead of one long freeze.
- A door's width is now measured once per door type instead of once per door, and the game
  no longer searches the entire world for doors twice every time a village map is rebuilt.
- The post-bake navmesh extent check is off by default. It re-examined every village's mesh
  after each rebuild — the single largest stall left — to produce one diagnostic line.
- **Diagnostics no longer fill your disk.** Three separate channels wrote to disk as you
  played, none of them capped or trimmed: a legacy line-per-event file that had reached 4GB,
  a per-rebuild JSON file that had left 3,451 files behind, and a per-rebuild telemetry line.
  Each opened and closed a file on the main thread. The first is deleted outright; the other
  two are off unless you turn them on, and what they recorded is in the normal log anyway.
  (Existing files already on disk are left alone — delete `BepInEx/config/vv_dumps` if you
  want the space back.)
- **A work order now belongs to the village its token is standing in.** Move the token to a
  chest in another village and the order moves with it, keeping the amounts you set. Take
  the token out and the order goes; put it back and it returns. Two villages can each run
  the same order, because each has its own token. An order whose village no longer exists
  isn't lost either — drop its token in any village's chest and that village takes it on.
  A token in your pocket is in transit, not gone, so nothing is removed while you carry it.
- Village territory no longer grows to swallow a neighbouring village's buildings when two
  settlements are close together; each building is attributed to whichever village it is
  nearest.
- `vv_probe`'s wall-flood section reports the village you are standing in rather than
  whichever village rebuilt most recently, and `vv_village anchors` includes the registry.
- `vv_path` works away from the first village: it sampled from a fixed height that only
  suited one village's altitude, and silently reported failure anywhere else.
- `vv_chestpolicy` scopes chests by village territory, matching what villagers actually see,
  instead of a radius that disagreed with them.
- Diagnostics that read the navmesh now warn when a rebuild is in progress, instead of
  reporting a half-rewritten one as fact.
- Calls into the game's internals that fail now say so in the log instead of silently
  reporting "no fire", "no fuel" or "nothing queued" and letting villagers act on it.
- A village is only ever removed once nothing is left of it — no villagers and no registry.
  It could previously be removed while villagers still lived there, orphaning their records.
- A new work order now defaults to **one full stack** of the item it produces, refilling at
  **half a stack**, instead of a flat 1-10. The old default ignored what was being made: it
  ordered a fifth of a stack of something that stacks to 50, and ten separate copies of
  something that does not stack at all.
- The `vv_` dev console surface is consolidated from 63 commands to 36. Dumps that describe
  one subject are now subcommands — `vv_village <list|at|anchors|stations|pois|orders>`,
  `vv_graph <regions|boundary|bfs>`, `vv_viz <path|tri|off>`,
  `vv_reset <all|stale|patrols|forage|markers>` and `vv_log <channel> [on|off]` — and the
  console tab-completes each group's subcommands.
- `vv_get_villagers` is now `vv_records -v`; `vv_beeprobe`/`vv_forageprobe` are
  `vv_harvestprobe`; `vv_bake_audit` is `vv_probe bake`; `vv_drawpath`/`vv_pathcompare` are
  `vv_path`; `vv_capture_at` is `vv_capture <x> <z>`.
- Commands that destroy or fabricate state (`vv_reset all`, `vv_damage_structures`,
  `vv_kill_villager`, `vv_set_record_status`) now require an explicit `--yes`.

## [0.2.8] - 2026-09-18

### New
- Farmers forage ripe berries, mushrooms and thistle in the village, on a work order
- Plants become orderable once you've picked one yourself

### Fixed
- Villagers no longer idle forever after being revived or after a world reload
- Carpenters no longer retry structures they can't reach; those wait until the village changes
- Craft progress bar no longer covers the Order button
- Ripe-crop scan covers the whole village, not a 20m circle around the anchor
- Harvest orders with nothing ready no longer log as unimplemented

### Changed
- Far less log spam; per-chest and item-spawn detail moved behind `vv_log_ingredients` and `vv_log_itemspawns`

## [0.2.7] - 2026-09-15

### Fixed
- Work orders for recipes that craft in batches (arrows and the like) now deliver the whole batch.  the villager was paying the full ingredient cost for the stack and then handing back a single item.
- Work order quantities are now counted from what is actually sitting in the village's chests rather than from what one villager remembers crafting, so an order stops at the right amount and picks itself back up when the stock gets used.

## [0.2.6] - 2026-09-13

### New
- Farmers can now harvest honey
- villagers will pause when their menu is opened
- crafted items will prefer being stored adjacent to their work orders.  other items will avoid being stored in chests with work orders.

### Fixed
- Scheduling villagers no longer get stuck on lower priority, unfulfillable tasks


## [0.2.4] - 2026-09-13

### Fixed
- Village navmesh graph no longer gets confused sometimes on dedicated servers
- Work orders in chests should be owned by dedicated server, not by individual players
- Villagers prioritize tasks more intelligently

## [0.2.3] - 2026-09-09

### Fixed
- **Compatibility with Valheim's 2026-09-09 update.** The update changed several
  engine interfaces the mod builds on, and the mod stopped working in visible ways:
  villagers could no longer be interacted with at all, and any villager that tried to
  put food in a cooking station or ore in a smelter threw and abandoned the job. Both
  are repaired — hovering a villager now grants the same reach as any other creature,
  and the station calls match the game's new signatures.
- **Villagers cooking on a cold fire.** A villager would walk to a cooking station,
  put meat on it and stand there while nothing cooked, because the mod asked the
  station whether it was lit rather than asking the fire. It now reads the fireplace's
  own state, so an unlit station is recognised as unusable — and when a villager has
  cooking to do and finds the fire out, they fetch fuel and relight it instead of
  giving up.
- **Villagers stalling beside a station or chest.** An approach point could land a few
  centimetres from the edge of the walkable area, which left the villager unable to
  finish the last step and stuck until something else interrupted them.
- **Villagers taking each other's jobs.** Two villagers could claim the same crafting
  task; the loser failed its assignment and went idle. Tasks are now owned by the
  villager that claimed them.
- **Workbench crafting produced items without consuming materials.** The workbench
  path deposited its output but never removed the ingredients it used, so orders could
  overshoot their quota and materials were never spent.
- **Villager records reported as orphaned.** Records whose NPC had been re-created
  (after a world reload) were listed as orphans instead of being re-linked to the
  villager they belong to.

### Added
- **Idle villagers with their own needs.** Instead of picking a leisure spot at
  random, villagers now build up warmth, company, rest and curiosity over time and
  choose what to do accordingly — gathering near each other, visiting the animals and
  the farm, heading for shelter when cold or exposed, and generally preferring the
  more comfortable parts of the village.
- **Villagers tell you when they are stuck.** A villager with a problem only you can
  fix now shows a floating "!" and says what is wrong when you come near: storage
  nearly full, a missing ingredient named from the recipe they actually know, or an
  output chest with no room left.
- **Chests holding a work order are reserved for it.** Villagers no longer fill a
  work-order chest with unrelated salvage — only that order's output, the recipe's
  ingredients, the fuel its station burns, and work orders themselves. Every slot
  taken by something else was a slot the order's output could not land in, which
  stalled the order outright.
- **The Village Registry has its own build-menu icon**, rendered from the piece
  itself, instead of showing the plain table it is built from.

## [0.2.2] - 2026-06-24

### Fixed
- **Rescue quest rewards at surface locations.** A rescue quest could send you to
  an above-ground site — a farm, camp, tower, or ruin — but the Lode Core reward
  only ever appeared if you stepped into a dungeon *interior*. Surface sites have
  no interior to enter, so those quests (most Meadows, Plains, and Ashlands
  rescues) led you to an empty location with nothing to collect. Rewards now
  recognize whether a quest points at an interior dungeon or a surface site:
  interior quests still place the core inside when you enter, and surface quests
  place it when you arrive at the marked location. Mixed-biome pools (Swamp,
  Mountain, Mistlands) are decided per chosen location.

## [0.2.1] - 2026-06-23

### Fixed
- **Map fragment rescue quests on dedicated servers.** Combining biome fragments
  did nothing when playing on a dedicated server: the search for a quest dungeon
  ran on your game client, which doesn't hold the world's location data (only the
  server does), so no location was ever found and the fragments were left unspent.
  The lookup now runs on the server and reports the chosen location back, so
  combining fragments reliably reveals a quest marker in every setup — dedicated
  server, player-hosted, and singleplayer. Fragments are still consumed only once a
  valid location is confirmed, so a failed search leaves them in your pack.

## [0.2.0] - 2026-06-23

### Added
- **Lode Core recruitment economy.** Recruiting and reviving villagers is now
  earned through exploration instead of being free:
  - Loot **biome map fragments** out in the world, then combine three fragments
    from the same biome to **unlock that biome's villager type** for recruitment
    and reveal a quest marker pointing to a dungeon.
  - Recover a **Lode Core** from the marked dungeon — the resource that recruiting
    or reviving a villager spends. A villager that dies drops its Lode Core, so it
    is recoverable rather than lost.
  - Fragments decide *which* villager types you can recruit (knowledge); Lode
    Cores decide *how many* villagers you can field (currency). Unlocks are
    tracked per player.
  - Lode Cores cannot be carried through portals.
  - Recruiting and reviving are atomic — a Lode Core is spent only if a villager
    actually spawns, and is refunded to you otherwise.
- The Village Registry's recruit and revive panels now show the Lode Core cost
  and which villager types you have unlocked.
- The work-order **Order** button on a crafting station now appears only when you
  have unlocked a villager type that can work that station, and its tooltip names
  the type.
- **Idle villagers relax.** A villager with no work seeks out a cozy spot — such
  as a hot tub — to relax instead of standing around.

### Changed
- **Smoother village (re)partition.** Rebuilding a village's navigation graph —
  which happens on structure changes and on load — caused noticeable hitches.
  The rebuild now does far less redundant work: per-cell ground heights are
  cached, and the wall-check flood skips the open ground away from any structure,
  cutting up to ~45% of the physics and ground-height queries per rebuild with no
  change to the result. Larger villages benefit the most.

### Developer
- New `[Region] PartitionProfile` log line reports per-stage timings and
  native-query counts for each region partition, for diagnosing rebuild cost.
- `vv_recruit` and `vv_revive` console commands remain free (no Lode Core cost)
  for testing.

### Upgrade note
- Recruiting and reviving now require Lode Cores, and recruiting a villager type
  requires first unlocking it by combining biome fragments. Villagers already
  living in your world are unaffected — only new recruits and revives draw on the
  new economy.

## [0.1.3] 2026-06-22

### Fixed
- Recipe lists on villager and Village Registry panels flickering, and
  occasionally ignoring a click. The custom tab lists were torn down and rebuilt
  on every refresh; they now rebuild only when their contents actually change.
- A vanilla crafting station opening on the wrong tab (stuck on Upgrade) after
  you had just talked to a villager. The villager UI now restores the game's
  crafting tabs to the state they were in before it took over.
- Villagers on dedicated servers unable to reach their chests or do any work.
  The server was instantiating every village building piece twice, which
  corrupted the walkable surface around chests — a server-owned villager would
  stall at a chest and never produce anything. Pieces are no longer duplicated,
  so villagers path to their chests reliably on a dedicated server.
- Craft-capable villagers (farmers, blacksmiths, carpenters) standing idle with
  work waiting. A villager handed a job by the scheduler could fail to actually
  start it and churn between "idle" and "no work"; assigned crafting and farming
  now begin reliably.
- Villagers producing output with no materials on hand, and overshooting a work
  order's maximum. Cooked meat (and other outputs) kept appearing after the raw
  ingredients ran out, and stored counts ran well past the configured cap.
  Villagers now craft only when the ingredients are actually present and stop at
  the order's maximum — counting what is already cooking on a station, not just
  what has finished.
- Work-order quantity edits snapping back to their previous values. Changing an
  order's min/max — especially while the chest was open or villagers were using
  it — could revert as the server and your game fought over the chest. Work-order
  quotas are now stored on the village and applied through the server, so edits
  take effect immediately and persist across reloads.

### Changed
- Work-order min/max settings are now stored on the village itself rather than on
  the order item in a chest, so quota edits no longer get overwritten by the
  server and your game contending for the chest.

### Upgrade note
- Work orders created in a previous version need a one-time migration after
  updating: with developer commands enabled, run `vv_migrate_workorders` on the
  server console once the world has loaded. Until then, previously-placed work
  orders are not picked up (the new version reads quotas from the village, not the
  chest item). Re-running the command is safe — it skips orders already migrated.
  **(Removed in 0.3.0 — this migration is no longer available. A world last played
  before 0.2 must be upgraded on 0.2.8 or earlier first.)**

## [0.1.2] - 2026-06-18

## [0.1.1] - 2026-06-14

### Fixed
- Villagers reverting to ordinary (hostile) Dvergr after a portal trip or zone
  reload. A villager you walked away from and returned to — through a portal, or
  by leaving and re-loading the area — could come back stripped of its role, AI,
  and equipment. Identity is now restored every time the world re-creates the
  NPC, not just the first time it loads in a session.
- Villages failing to come online after a save is loaded, most often on dedicated
  servers. The region graph could be built before the area finished streaming in,
  leaving villagers unable to locate their region — idle, never finishing
  "mapping" their village, never patrolling or working. The graph build now waits
  until the village's zone is loaded and its pieces are instantiated before it
  runs, and defers itself otherwise.

### Changed
- The Registry station is now the sole anchor for a village; the earlier
  bed-as-anchor system has been removed. Beds are once again ordinary player
  furniture and no longer affect villager assignment.

## [0.1.0] - 2026-06-13

### Added
- First early-access release for server testing.
- Villagers that map an enclosed village, locate stations and containers, and
  fulfill work orders from available materials (harvest/replant, refine coal,
  smelt ore, roast meat, sweep ground items to chests).
- Navigation across doors, player-made stairs, modified terrain, walls and
  ramparts, backed by an async navmesh-rebake task queue.
- Village registry station to recruit and revive villagers, view villager
  status, and identify an enclosed area as a village.
- Work-order items with a slider UI for min/max quantities and composite icons.
- Village mapping (boundary flood-fill + HNA region graph) and custom UI tabs
  with improved controller / Steam Deck support.

### Known limitations
- Melee villager combat is not implemented; guards use crossbows and
  non-combatants flee.
- Navmesh edge cases around shallow stairs, low floor gaps, and doors on terrain
  can strand villagers — prefer wide stairs/ramps and generous clearance.
- Rescue quests and map fragments are experimental and largely untested.
- Away-from-base simulation may stall until the player loads the relevant tile.

[Unreleased]: https://github.com/myrcutio/valheim_villages/compare/v0.2.0...HEAD
[0.2.0]: https://github.com/myrcutio/valheim_villages/compare/v0.1.3...v0.2.0
[0.1.3]: https://github.com/myrcutio/valheim_villages/compare/v0.1.1...v0.1.3
[0.1.1]: https://github.com/myrcutio/valheim_villages/compare/v0.1.0...v0.1.1
[0.1.0]: https://github.com/myrcutio/valheim_villages/releases/tag/v0.1.0
